
# Controle de gastos - Build Automático

## Como usar
1. Crie um repositório no GitHub.
2. Envie todos os arquivos deste projeto para o repositório.
3. Vá em **Actions** no GitHub e ative workflows.
4. O GitHub Actions vai compilar o APK automaticamente a cada commit.
5. O APK ficará disponível como artefato para download na aba **Actions**.

## Nome do App
- Nome: Controle de gastos
- ID: com.controledegastos
